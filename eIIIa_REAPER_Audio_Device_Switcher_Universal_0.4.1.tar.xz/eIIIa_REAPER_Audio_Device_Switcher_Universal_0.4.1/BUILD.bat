@echo off
setlocal
cd /d "%~dp0"
set EIIIA_BUILD_ONLY=1
call BUILD_AND_INSTALL.bat --build-only
