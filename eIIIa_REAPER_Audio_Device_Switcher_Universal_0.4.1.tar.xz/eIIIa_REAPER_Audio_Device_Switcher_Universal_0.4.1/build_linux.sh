#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
command -v cmake >/dev/null || { echo "CMake is required."; exit 1; }
command -v git >/dev/null || { echo "git is required."; exit 1; }
command -v c++ >/dev/null || { echo "A C++17 compiler is required."; exit 1; }
./scripts/fetch_deps.sh
./tests/test_compact_menu.sh
./tests/test_portable_policy.sh
./tests/test_crossplatform_menu_policy.sh
./tests/test_universal_build_policy.sh
./tests/test_transport_stop_integration.sh
cmake -S . -B build/cmake -DCMAKE_BUILD_TYPE=Release
cmake --build build/cmake --config Release
ctest --test-dir build/cmake -C Release --output-on-failure
cp -f build/cmake/reaper_eIIIa_audio_device_switcher.so build/reaper_eIIIa_audio_device_switcher.so
echo "Built: $PWD/build/reaper_eIIIa_audio_device_switcher.so"
