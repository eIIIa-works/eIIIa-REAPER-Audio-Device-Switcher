#include "raw_string_buffer.h"
#include <cassert>
#include <cstring>
#include <iostream>

using namespace eiiia;

int main() {
  {
    char buf[32] = "MacBook Speakers";
    auto s = read_raw_string_buffer(buf, sizeof(buf));
    assert(s && *s == "MacBook Speakers");
    assert(write_raw_string_buffer(buf, sizeof(buf), "ZOOM H5"));
    assert(std::strcmp(buf, "ZOOM H5") == 0);
  }
  {
    char buf[8] = "1234567";
    assert(!write_raw_string_buffer(buf, sizeof(buf), "too-long"));
    assert(std::strcmp(buf, "1234567") == 0);
  }
  {
    unsigned char binary[8] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x00};
    assert(!read_raw_string_buffer(binary, sizeof(binary)).has_value());
  }
  {
    // No NUL terminator within the declared storage means it is not a safe char buffer.
    char buf[4] = {'a','b','c','d'};
    assert(!read_raw_string_buffer(buf, sizeof(buf)).has_value());
  }
  std::cout << "raw_string_buffer tests passed\n";
  return 0;
}
