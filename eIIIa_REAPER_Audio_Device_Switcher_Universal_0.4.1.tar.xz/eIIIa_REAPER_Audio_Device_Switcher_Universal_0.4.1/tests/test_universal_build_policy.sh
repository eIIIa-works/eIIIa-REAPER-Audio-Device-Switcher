#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
C="$ROOT/CMakeLists.txt"
for bad in 'if(NOT APPLE)' 'currently targets REAPER on macOS'; do if grep -q "$bad" "$C"; then echo "FAIL: macOS-only CMake gate remains"; exit 1; fi; done
for need in 'WIN32' 'APPLE' 'CMAKE_SYSTEM_NAME STREQUAL "Linux"' 'device_window_native.cpp' 'portable_audio_controller.cpp'; do grep -q "$need" "$C" || { echo "FAIL: CMake missing $need"; exit 1; }; done
for f in BUILD_AND_INSTALL.command BUILD_AND_INSTALL.bat BUILD_AND_INSTALL.sh; do test -f "$ROOT/$f" || { echo "FAIL: missing $f"; exit 1; }; done
echo 'PASS: universal build policy'
