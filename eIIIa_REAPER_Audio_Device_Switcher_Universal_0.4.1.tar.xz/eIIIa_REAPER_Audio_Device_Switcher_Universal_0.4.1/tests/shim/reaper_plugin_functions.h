#pragma once
#include "reaper_plugin.h"
inline int REAPERAPI_LoadAPI(void*(*)(const char*)){return 0;}
inline void (*Audio_Init)()=nullptr;
inline void (*Audio_Quit)()=nullptr;
inline bool (*GetAudioDeviceInfo)(const char*,char*,int)=nullptr;
inline bool (*get_config_var_string)(const char*,char*,int)=nullptr;
inline int (*set_config_var_string)(const char*,const char*,bool)=nullptr;
inline const char* (*get_ini_file)()=nullptr;
inline const char* (*GetExtState)(const char*,const char*)=nullptr;
inline void (*SetExtState)(const char*,const char*,const char*,bool)=nullptr;
inline void (*ShowConsoleMsg)(const char*)=nullptr;
inline const char* (*GetResourcePath)()=nullptr;
inline void (*Main_OnCommand)(int,int)=nullptr;
inline int (*GetPlayState)()=nullptr;
inline void (*OnStopButton)()=nullptr;
