#pragma once
#include <cstdint>
#include <cstddef>
typedef void* HWND; typedef void* HMENU; typedef void* HINSTANCE; typedef long LRESULT; typedef long LPARAM; typedef unsigned long WPARAM; typedef unsigned int UINT; typedef int BOOL; typedef long LONG_PTR; typedef std::uintptr_t UINT_PTR;
struct POINT{long x=0,y=0;}; struct RECT{long left=0,top=0,right=0,bottom=0;};
#define TRUE 1
#define FALSE 0
#define REAPER_PLUGIN_VERSION 0x20E
#define REAPER_PLUGIN_DLL_EXPORT
#define REAPER_PLUGIN_ENTRYPOINT ReaperPluginEntry
#define REAPER_PLUGIN_HINSTANCE HINSTANCE
#define GWL_ID (-12)
#define CB_GETCOUNT 0x0146
#define CB_GETCURSEL 0x0147
#define CB_GETLBTEXT 0x0148
#define CB_GETLBTEXTLEN 0x0149
#define CB_SETCURSEL 0x014E
#define CBN_SELCHANGE 1
#define WM_COMMAND 0x0111
#define WM_CLOSE 0x0010
#define BN_CLICKED 0
#define SW_HIDE 0
#define IDOK 1
#define IDCANCEL 2
#define MF_STRING 0
#define MF_ENABLED 0
#define MF_GRAYED 1
#define MF_SEPARATOR 0x800
#define MF_BYPOSITION 0x400
#define MF_BYCOMMAND 0
#define MF_CHECKED 8
#define MF_UNCHECKED 0
#define TPM_RETURNCMD 0x100
#define TPM_NONOTIFY 0x80
#define MAKEWPARAM(l,h) ((WPARAM)(((unsigned short)(l)) | ((unsigned long)((unsigned short)(h)))<<16))
struct ACCEL_SHIM{int cmd=0;int fVirt=0;int key=0;}; struct gaccel_register_t{ACCEL_SHIM accel; const char* desc=nullptr;};
struct reaper_plugin_info_t{int caller_version=REAPER_PLUGIN_VERSION; HWND hwnd_main=nullptr; void*(*GetFunc)(const char*)=nullptr; int(*Register)(const char*,void*)=nullptr;};
extern "C" BOOL EnumChildWindows(HWND, BOOL(*)(HWND,LPARAM), LPARAM);
extern "C" BOOL EnumWindows(BOOL(*)(HWND,LPARAM), LPARAM);
extern "C" BOOL IsWindowVisible(HWND);
extern "C" BOOL ShowWindow(HWND,int);
extern "C" HWND GetParent(HWND);
extern "C" LONG_PTR GetWindowLong(HWND,int);
extern "C" BOOL GetWindowRect(HWND,RECT*);
extern "C" int GetWindowText(HWND,char*,int);
extern "C" int GetWindowTextLength(HWND);
extern "C" LRESULT SendMessage(HWND,UINT,WPARAM,LPARAM);
extern "C" HMENU CreatePopupMenu();
extern "C" void DestroyMenu(HMENU);
extern "C" int GetMenuItemCount(HMENU);
extern "C" void InsertMenu(HMENU,int,unsigned int,UINT_PTR,const char*);
extern "C" bool CheckMenuItem(HMENU,int,int);
extern "C" int TrackPopupMenu(HMENU,int,int,int,int,HWND,const RECT*);
extern "C" void GetCursorPos(POINT*);
extern "C" HWND GetForegroundWindow();
#ifdef _WIN32
#define CP_UTF8 65001
extern "C" int WideCharToMultiByte(UINT,unsigned long,const wchar_t*,int,char*,int,const char*,BOOL*);
extern "C" int MultiByteToWideChar(UINT,unsigned long,const char*,int,wchar_t*,int);
extern "C" int GetWindowTextLengthW(HWND);
extern "C" int GetWindowTextW(HWND,wchar_t*,int);
extern "C" LRESULT SendMessageW(HWND,UINT,WPARAM,LPARAM);
extern "C" BOOL AppendMenuW(HMENU,UINT,UINT_PTR,const wchar_t*);
#endif
