#include "config_mapping.h"
#include <cassert>
#include <iostream>

using namespace eiiia;

static DeviceIdentity dev(uint32_t id, const char* uid, const char* name, bool in=true, bool out=true) {
  DeviceIdentity d;
  d.audio_device_id = id;
  d.uid = uid;
  d.name = name;
  d.has_input = in;
  d.has_output = out;
  return d;
}

int main() {
  const auto mac = dev(41, "AppleHDAEngineInput:1B,0,1,0:1", "MacBook Pro Microphone", true, false);
  const auto zoom = dev(87, "ZOOM_H5_UID", "ZOOM H5", true, true);

  {
    std::vector<ConfigEntry> entries = {
      {"coreaudio_input_device", mac.uid, true},
      {"coreaudio_output_device", "Built-in Output UID", true},
    };
    auto b = discover_binding(entries, mac, Direction::Input);
    assert(b.has_value());
    assert(b->key == "coreaudio_input_device");
    auto v = rewrite_for_target(*b, mac, zoom);
    assert(v.has_value());
    assert(*v == zoom.uid);
  }

  {
    std::vector<ConfigEntry> entries = {
      {"ca_devin", "device=AppleHDAEngineInput:1B,0,1,0:1;channels=2", true},
      {"unrelated", "MacBook Pro Microphone", false},
    };
    auto b = discover_binding(entries, mac, Direction::Input);
    assert(b.has_value());
    assert(b->key == "ca_devin");
    auto v = rewrite_for_target(*b, mac, zoom);
    assert(v.has_value());
    assert(*v == "device=ZOOM_H5_UID;channels=2");
  }

  {
    std::vector<ConfigEntry> entries = {
      {"audio_device_in", "41", true},
      {"audio_device_out", "99", true},
    };
    auto b = discover_binding(entries, mac, Direction::Input);
    assert(b.has_value());
    assert(b->key == "audio_device_in");
    auto v = rewrite_for_target(*b, mac, zoom);
    assert(v.has_value());
    assert(*v == "87");
  }

  {
    // Direction scoring must prefer an input-specific key over a generic key.
    std::vector<ConfigEntry> entries = {
      {"coreaudio_device", mac.name, true},
      {"coreaudio_input", mac.name, true},
    };
    auto b = discover_binding(entries, mac, Direction::Input);
    assert(b.has_value());
    assert(b->key == "coreaudio_input");
  }

  {
    // A key that is not runtime writable must never be selected.
    std::vector<ConfigEntry> entries = {
      {"coreaudio_input", mac.uid, false},
    };
    auto b = discover_binding(entries, mac, Direction::Input);
    assert(!b.has_value());
  }

  {
    // Hidden CoreAudio preferences may be applied by rewriting REAPER's own INI and reopening the audio engine.
    std::vector<ConfigEntry> entries = {
      {"coreaudioindevnew", mac.name, true, ConfigWriteMethod::IniFileReload},
    };
    auto b = discover_binding(entries, mac, Direction::Input);
    assert(b.has_value());
    assert(b->key == "coreaudioindevnew");
    assert(b->write_method == ConfigWriteMethod::IniFileReload);
  }

  {
    // No current-device identity in the value: do not guess.
    std::vector<ConfigEntry> entries = {
      {"coreaudio_input", "some-other-device", true},
    };
    auto b = discover_binding(entries, mac, Direction::Input);
    assert(!b.has_value());
  }


  {
    // A single serialized REAPER preference may contain both input and output identities.
    const auto outdev = dev(55, "BUILTIN_OUT_UID", "Built-in Output", false, true);
    ConfigBinding inb{"coreaudio_devices", "in=" + mac.uid + ";out=" + outdev.uid, Direction::Input, ValueEncoding::UidEmbedded, 1};
    auto first = rewrite_for_target(inb, mac, zoom);
    assert(first.has_value());
    ConfigBinding outb{"coreaudio_devices", *first, Direction::Output, ValueEncoding::UidEmbedded, 1};
    auto second = rewrite_for_target(outb, outdev, zoom);
    assert(second.has_value());
    assert(*second == "in=ZOOM_H5_UID;out=ZOOM_H5_UID");
  }

  std::cout << "config_mapping tests passed\n";
  return 0;
}
