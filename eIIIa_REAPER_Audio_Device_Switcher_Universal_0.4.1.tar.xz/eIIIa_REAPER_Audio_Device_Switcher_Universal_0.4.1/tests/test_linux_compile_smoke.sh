#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
FILES=(src/plugin_main.cpp src/plugin_state.cpp src/portable_audio_controller.cpp src/transport_guard.cpp src/device_window_native.cpp src/audio_profile.cpp src/prefs_model.cpp src/native_control_model.cpp src/slot_assignment.cpp src/config_mapping.cpp src/prefs_popup_logic.cpp src/audio_config_bridge.cpp src/ini_device_prefs.cpp src/ini_writer.cpp)
for f in "${FILES[@]}"; do
  g++ -std=c++17 -fsyntax-only -DSWELL_PROVIDED_BY_APP -DSWELL_TARGET_GDK -Itests/shim -Isrc "$f"
done
echo 'PASS: Linux/SWELL source compile smoke'
