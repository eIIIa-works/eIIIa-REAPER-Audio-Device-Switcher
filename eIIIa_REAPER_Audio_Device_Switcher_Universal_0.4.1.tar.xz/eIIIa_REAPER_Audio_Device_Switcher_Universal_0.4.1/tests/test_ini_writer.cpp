#include "ini_writer.h"
#include <cassert>
#include <fstream>
#include <iostream>
#include <string>
using namespace eiiia;

static std::string readall(const char* p) {
  std::ifstream f(p, std::ios::binary);
  return std::string((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
}

int main() {
  const char* path = "/tmp/eiiia_reaper_ini_writer_test.ini";
  {
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    f << "[REAPER]\nfoo=1\ncoreaudiooutdevnew=Old Device\ncoreaudioindevnew=Old Input\n\n[audioconfig]\nmode=0\n";
  }
  std::string err;
  assert(write_ini_key(path, "REAPER", "coreaudiooutdevnew", "External Headphones", &err));
  auto s = readall(path);
  assert(s.find("coreaudiooutdevnew=External Headphones") != std::string::npos);
  assert(s.find("coreaudioindevnew=Old Input") != std::string::npos);
  assert(s.find("[audioconfig]\nmode=0") != std::string::npos);
  assert(write_ini_key(path, "REAPER", "coreaudioindevnew", "Background Music", &err));
  s = readall(path);
  assert(s.find("coreaudioindevnew=Background Music") != std::string::npos);
  std::remove(path);
  std::cout << "ini_writer tests passed\n";
}
