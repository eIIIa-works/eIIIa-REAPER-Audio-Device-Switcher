#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
API="$ROOT/src/reaper_api.h"
STATE="$ROOT/src/plugin_state.cpp"

grep -q 'REAPERAPI_WANT_GetPlayState' "$API" || { echo 'FAIL: GetPlayState API not requested'; exit 1; }
grep -q 'REAPERAPI_WANT_OnStopButton' "$API" || { echo 'FAIL: OnStopButton API not requested'; exit 1; }
# Both macOS and portable branches must guard menu/discovery and direct device switching.
COUNT="$(grep -c 'if (!stopTransportBeforeAudioAction()) return;' "$STATE" || true)"
[ "$COUNT" -ge 4 ] || { echo "FAIL: expected transport guard at both entry points in both platform branches (found $COUNT)"; exit 1; }
echo 'PASS: transport stop integration policy'
