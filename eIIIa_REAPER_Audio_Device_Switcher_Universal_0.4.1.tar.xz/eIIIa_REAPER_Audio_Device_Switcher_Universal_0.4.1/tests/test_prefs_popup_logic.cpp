#include "prefs_popup_logic.h"
#include <cassert>
#include <iostream>
using namespace eiiia;
int main() {
  {
    std::vector<PopupSnapshot> p = {
      {"F Series Stereo Track Usb Audio", {"F Series Stereo Track Usb Audio", "External Headphones", "27EA63"}},
      {"48000", {"44100", "48000", "96000"}}
    };
    auto v = choose_audio_popup_indices(p, "F Series Stereo Track Usb Audio", "F Series Stereo Track Usb Audio", "External Headphones", false, true);
    assert((v == std::vector<size_t>{0}));
  }
  {
    std::vector<PopupSnapshot> p = {
      {"F Series Stereo Track Usb Audio", {"F Series Stereo Track Usb Audio", "Background Music"}},
      {"F Series Stereo Track Usb Audio", {"F Series Stereo Track Usb Audio", "Background Music"}},
    };
    auto v = choose_audio_popup_indices(p, "F Series Stereo Track Usb Audio", "F Series Stereo Track Usb Audio", "Background Music", true, true);
    assert(v.size() == 2 && v[0] == 0 && v[1] == 1);
  }
  {
    std::vector<PopupSnapshot> p = {
      {"MacBook Microphone", {"MacBook Microphone", "Background Music"}},
      {"F Series Stereo Track Usb Audio", {"F Series Stereo Track Usb Audio", "Background Music"}},
    };
    auto v = choose_audio_popup_indices(p, "MacBook Microphone", "F Series Stereo Track Usb Audio", "Background Music", true, true);
    assert(v.size() == 2);
  }
  {
    std::vector<PopupSnapshot> p = {
      {"F Series Stereo Track Usb Audio", {"F Series Stereo Track Usb Audio", "External Headphones"}},
      {"F Series Stereo Track Usb Audio", {"F Series Stereo Track Usb Audio", "External Headphones"}},
    };
    auto v = choose_audio_popup_indices(p, "F Series Stereo Track Usb Audio", "F Series Stereo Track Usb Audio", "External Headphones", false, true);
    assert(v.empty()); // ambiguous: do not guess which is output
  }
  assert(strip_coreaudio_ident("CoreAudio F Series Stereo Track Usb Audio") == "F Series Stereo Track Usb Audio");
  assert(strip_coreaudio_ident("F Series Stereo Track Usb Audio") == "F Series Stereo Track Usb Audio");
  std::cout << "prefs_popup_logic tests passed\n";
}
