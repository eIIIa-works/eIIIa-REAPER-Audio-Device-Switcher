#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/src/device_window.mm"
if grep -q 'REAPER  Input:' "$SRC"; then
  echo 'FAIL: switcher menu still renders the redundant REAPER Input/Output header' >&2
  exit 1
fi
if grep -q 'impl_->status.empty' "$SRC"; then
  echo 'FAIL: switcher menu still renders the redundant bottom status row' >&2
  exit 1
fi
if ! grep -q 'Refresh interfaces' "$SRC" || ! grep -q 'Rebuild slots 1–9' "$SRC"; then
  echo 'FAIL: functional menu commands disappeared' >&2
  exit 1
fi
echo 'PASS: switcher menu is compact and functional-only'
