#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STATE="$ROOT/src/plugin_state.cpp"
BRIDGE="$ROOT/src/reaper_prefs_bridge.mm"

# Live switching must route through REAPER's own Audio Device preferences action,
# not mutate macOS default audio or fake mouse coordinates.
grep -q 'kAudioDevicePrefsCommand = 40099' "$STATE" || {
  echo "FAIL: native Audio Device Preferences action is not used" >&2; exit 1;
}
grep -q 'sendAction' "$BRIDGE" || {
  echo "FAIL: popup selection-change action is not dispatched natively" >&2; exit 1;
}
grep -q 'performClick' "$BRIDGE" || {
  echo "FAIL: Preferences OK handler is not invoked" >&2; exit 1;
}
if grep -R -nE 'osascript|System Events|SwitchAudioSource|kAudioHardwarePropertyDefault(Input|Output)Device|CGEventCreateMouseEvent' "$ROOT/src" >/dev/null 2>&1; then
  echo "FAIL: system audio or mouse automation code detected" >&2; exit 1;
fi
if grep -q 'apply_config_changes' "$STATE"; then
  echo "FAIL: old INI/runtime config-switch path is still used by PluginState" >&2; exit 1;
fi

echo "prefs_bridge_policy tests passed"
