#include "audio_profile.h"
#include <cassert>
#include <iostream>
using namespace eiiia;
int main(){
  AudioProfile p;
  p.audio_system="ASIO";
  p.selectors={{"driver","RME Fireface USB"}};
  p.display_name="ASIO — RME Fireface USB";
  const auto id1=make_profile_stable_id(p);
  const auto id2=make_profile_stable_id(p);
  assert(!id1.empty());
  assert(id1==id2);
  AudioProfile q=p; q.selectors[0].value="F Series";
  assert(make_profile_stable_id(q)!=id1);
  assert(profile_display_name("CoreAudio", "External Headphones", false)=="External Headphones");
  assert(profile_display_name("ASIO", "RME Fireface USB", true)=="ASIO — RME Fireface USB");
  std::cout<<"PASS: audio profile identity\n";
}
