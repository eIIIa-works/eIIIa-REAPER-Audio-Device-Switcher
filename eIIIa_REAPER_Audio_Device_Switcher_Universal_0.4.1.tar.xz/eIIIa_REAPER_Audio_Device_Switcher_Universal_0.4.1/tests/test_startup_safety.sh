#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAIN="$ROOT/src/plugin_main.cpp"
STATE="$ROOT/src/plugin_state.cpp"

# Entry point must never initialize the state/UI during REAPER splash loading.
if grep -q 'PluginState::instance().initialize' "$MAIN"; then
  echo "FAIL: plugin entrypoint initializes PluginState during load" >&2
  exit 1
fi
if ! grep -q 'PluginState::destroyInstance' "$MAIN"; then
  echo "FAIL: unload path must not instantiate PluginState" >&2
  exit 1
fi
# DeviceWindow must be lazy, not an inline member constructed with PluginState.
if grep -qE '^\s*DeviceWindow\s+window_;' "$ROOT/src/plugin_state.h"; then
  echo "FAIL: DeviceWindow is eagerly constructed" >&2
  exit 1
fi
if ! grep -q 'std::unique_ptr<DeviceWindow> window_' "$ROOT/src/plugin_state.h"; then
  echo "FAIL: lazy DeviceWindow ownership missing" >&2
  exit 1
fi
if ! grep -q 'std::make_unique<DeviceWindow>' "$STATE"; then
  echo "FAIL: lazy DeviceWindow creation missing" >&2
  exit 1
fi

echo "startup_safety tests passed"
