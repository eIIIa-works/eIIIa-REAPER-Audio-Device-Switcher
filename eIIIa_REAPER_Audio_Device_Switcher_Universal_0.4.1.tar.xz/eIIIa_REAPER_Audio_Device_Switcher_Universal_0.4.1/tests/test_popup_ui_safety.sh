#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# The switcher UI must be a transient menu, not a persistent window/panel.
if grep -R -nE 'NSPanel|makeKeyAndOrderFront|activateIgnoringOtherApps' "$ROOT/src/device_window.mm" >/dev/null 2>&1; then
  echo "FAIL: persistent AppKit window code is still present" >&2
  exit 1
fi
if ! grep -q 'NSMenu' "$ROOT/src/device_window.mm"; then
  echo "FAIL: transient NSMenu popup implementation missing" >&2
  exit 1
fi
if ! grep -q 'mouseLocation' "$ROOT/src/device_window.mm"; then
  echo "FAIL: popup is not positioned at current mouse location" >&2
  exit 1
fi
echo "popup_ui_safety tests passed"
