#include "slot_assignment.h"
#include <cassert>
#include <iostream>
using namespace eiiia;

static DeviceIdentity d(uint32_t id,const char* uid,const char* name){DeviceIdentity x; x.audio_device_id=id;x.uid=uid;x.name=name;x.has_output=true;return x;}

int main(){
  std::vector<std::string> slots(9);
  slots[0]="uid-b";
  std::vector<DeviceIdentity> devices={d(1,"uid-a","A"),d(2,"uid-b","B"),d(3,"uid-c","C")};
  auto out=ensure_slot_assignments(slots,devices,9);
  assert(out.size()==9);
  assert(out[0]=="uid-b");
  assert(out[1]=="uid-a");
  assert(out[2]=="uid-c");
  auto rows=build_slot_rows(out,devices);
  assert(rows.size()==3);
  assert(rows[0].slot==1 && rows[0].device->uid=="uid-b");
  assert(rows[1].slot==2 && rows[1].device->uid=="uid-a");
  assert(rows[2].slot==3 && rows[2].device->uid=="uid-c");
  std::cout<<"slot_assignment tests passed\n";
}
