#include "config_mapping.h"
#include <cassert>
#include <iostream>
using namespace eiiia;

int main() {
  assert(config_write_method_for_entry("coreaudiooutdevnew", false) == ConfigWriteMethod::IniFileReload);
  assert(config_write_method_for_entry("coreaudioindevnew", false) == ConfigWriteMethod::IniFileReload);
  assert(config_write_method_for_entry("coreaudiooutdevnew", true) == ConfigWriteMethod::SetConfigVarString);
  assert(config_write_method_for_entry("some_other_hidden_key", false) == ConfigWriteMethod::None);
  std::cout << "coreaudio_write_policy tests passed\n";
}
