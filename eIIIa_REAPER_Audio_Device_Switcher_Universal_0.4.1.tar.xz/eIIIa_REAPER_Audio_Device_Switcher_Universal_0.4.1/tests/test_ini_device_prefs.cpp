#include "ini_device_prefs.h"
#include <cassert>
#include <iostream>
#include <sstream>

int main() {
  std::istringstream ini(R"INI(
[audioconfig]
mode=5
asio_bsize=256

[REAPER]
coreaudiobs=128
coreaudioindevnew=F Series Stereo Track Usb Audio
coreaudiooutdevnew=External Headphones
unrelated_pref=42

[other]
coreaudioindevnew=Wrong Device
)INI");

  const auto entries = eiiia::parse_reaper_audio_preferences(ini);
  bool mode = false, in = false, out = false, unrelated = false, wrong = false;
  for (const auto& kv : entries) {
    if (kv.first == "mode" && kv.second == "5") mode = true;
    if (kv.first == "coreaudioindevnew" && kv.second == "F Series Stereo Track Usb Audio") in = true;
    if (kv.first == "coreaudiooutdevnew" && kv.second == "External Headphones") out = true;
    if (kv.first == "unrelated_pref") unrelated = true;
    if (kv.first == "coreaudioindevnew" && kv.second == "Wrong Device") wrong = true;
  }
  assert(mode);
  assert(in);
  assert(out);
  assert(!unrelated);
  assert(!wrong);
  std::cout << "ini_device_prefs tests passed\n";
}
