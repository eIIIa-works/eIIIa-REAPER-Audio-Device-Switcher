#!/bin/bash
set -euo pipefail
ROOT="$(mktemp -d)"
trap 'rm -rf "$ROOT"' EXIT
SDK="$ROOT/reaper-sdk"
WDL_SOURCE="$ROOT/wdl-source"
mkdir -p "$SDK/sdk" "$WDL_SOURCE/WDL/swell"
printf '/* fake */\n' > "$WDL_SOURCE/WDL/swell/swell.h"

"$(cd "$(dirname "$0")/.." && pwd)/scripts/link_wdl_into_sdk.sh" "$SDK" "$WDL_SOURCE"

[ -L "$SDK/WDL" ]
[ -f "$SDK/WDL/swell/swell.h" ]
TARGET="$(readlink "$SDK/WDL")"
[ "$TARGET" = "$WDL_SOURCE/WDL" ]

echo "wdl_layout tests passed"
